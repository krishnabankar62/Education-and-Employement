function checkMobileNumber(mobile_number)
{
    var my_expression = /^\d{10}$/;
    if(mobile_number.value.match(my_expression))
    {
        document.getElementById("mobile_number_id").innerHTML = "your Mobile number looks good !";
        document.getElementById("mobile_number_id").style.color="green";
        return true;
    }
    else if(mobile_number.value=="")
    {
        document.getElementById("mobile_number_id").innerHTML = "";
        return true;
    }
    else
    {
        //alert("message")
        document.getElementById("mobile_number_id").innerHTML = "Mobile number is not valid !";
        document.getElementById("mobile_number_id").style.color="red";
        return false;
    }
}

function checkCountryCode(country_code)
{
    var my_expression = /^\+?([0-9]{2})$/;
    if(country_code.value.match(my_expression))
    {
        document.getElementById("country_code_id").innerHTML = "contry code looks good !";
        document.getElementById("country_code_id").style.color="green";
        return true;
    }
    else if(country_code.value=="")
    {
        document.getElementById("country_code_id").innerHTML = "";
        return true;
    }
    else
    {
        //alert("message")
        document.getElementById("country_code_id").innerHTML = "country code is not valid !";
        document.getElementById("country_code_id").style.color="red";
        return false;
    }
}


function checkEmail(email)
{
    var my_expression = /^([a-zA-Z0-9_\-\.])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if(my_expression.test(email.value))
    {
        document.getElementById("email_id").innerHTML = "your email_id looks good !";
        document.getElementById("email_id").style.color="green";
        return true;
    }
    else if(email.value=="")
    {
        document.getElementById("email_id").innerHTML = "";
        return true;
    }
    else
    {
        //alert("message")
        document.getElementById("email_id").innerHTML = "email_id is not valid !";
        document.getElementById("email_id").style.color="red";
        return false;
    }
}


function checkAcNumber(ac_number)
{
    var my_expression = /^(?:[0-9]{11}|[0-9]{2}-[0-9]{3}-[0-9]{6})$/;
    if(my_expression.test(ac_number.value))
    {
        document.getElementById("ac_number").innerHTML = "your ac_number looks good !";
        document.getElementById("ac_number").style.color="green";
        return true;
    }
    else if(ac_number.value=="")
    {
        document.getElementById("ac_number").innerHTML = "";
        return true;
    }
    else
    {
        //alert("message")
        document.getElementById("ac_number").innerHTML = "ac_number is Not valid !";
        document.getElementById("ac_number").style.color="red";
        return false;
    }
}


function checkAadharNumber(aadhar_number)
{
    var my_expression = /^(?:([0-9]{12}|[0-9]{16})|(([0-9]{4}-[0-9]{4}-[0-9]{4})|([0-9]{4}-[0-9]{4}-[0-9]{4}-[0-9]{4})))$/;
    if(my_expression.test(aadhar_number.value))
    {
        document.getElementById("aadhar_id").innerHTML = "your aadhar_number looks good !";
        document.getElementById("aadhar_id").style.color="green";
        return true;
    }
    else if(aadhar_number.value=="")
    {
        document.getElementById("aadhar_id").innerHTML = "";
        return true;
    }
    else
    {
        //alert("message")
        document.getElementById("aadhar_id").innerHTML = "aadhar_number is Not valid !";
        document.getElementById("aadhar_id").style.color="red";
        return false;
    }
}



function checkName(name)
{
    var my_expression = /^[a-zA-Z]+\s[a-zA-Z]+$/;
    if(my_expression.test(name.value))
    {
        document.getElementById("name_id").innerHTML = "your name looks good !";
        document.getElementById("name_id").style.color="green";
        return true;
    }
    else if(name.value=="")
    {
        document.getElementById("name_id").innerHTML = "";
        return true;
    }
    else
    {
        //alert("message")
        document.getElementById("name_id").innerHTML = "name is Not valid !";
        document.getElementById("name_id").style.color="red";
        return false;
    }
}


function checkCnfPassWord(CnfPassWord)
{
    var PassWord = document.getElementById("PassWord").value;
    
    if(PassWord===CnfPassWord.value)
    {
        document.getElementById("cnf_PassWord_id").innerHTML = "your PassWord looks good !";
        document.getElementById("cnf_PassWord_id").style.color="green";
        return true;
    }
    else if(CnfPassWord.value==="" || PassWord==="")
    {
        document.getElementById("cnf_PassWord_id").innerHTML = "";
        return true;
    }
    else
    {
        //alert("message")
        document.getElementById("cnf_PassWord_id").innerHTML = "PassWord did Not matched !";
        document.getElementById("cnf_PassWord_id").style.color="red";
        return false;
    }
}




